# Menu principal de gitinfect
bash .banner
echo "Introduce la opcion que deseas realizar:"
echo ""
echo "1)Crear git infectado"
echo "2)Comprimir git infectado"
echo "3)Ayuda"
echo "4)Salir"
echo ""
read input
bash .$input






